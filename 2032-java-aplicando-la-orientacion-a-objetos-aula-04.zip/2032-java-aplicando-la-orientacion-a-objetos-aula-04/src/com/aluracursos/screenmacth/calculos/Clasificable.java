package com.aluracursos.screenmacth.calculos;

public interface Clasificable {
    int getClasificacion();
}
